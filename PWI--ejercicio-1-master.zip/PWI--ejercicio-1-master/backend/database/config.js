module.exports = {
    sqlite: {
        db: {
            dialect: 'sqlite',
            storage: './database/db.sqlite'
        }
    }
}