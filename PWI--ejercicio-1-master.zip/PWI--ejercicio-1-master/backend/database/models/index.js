module.exports = {
    Cliente: require('./Cliente'),
    Producto: require('./Producto'),
    ClienteProducto: require('./ClienteProducto')
}